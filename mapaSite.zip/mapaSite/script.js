// Selecionando as áreas clicáveis e a imagem do mapa
const areas = document.querySelectorAll('.area-link');
const imagem = document.getElementById('mapa');

// Loop para adicionar eventos nas áreas clicáveis
areas.forEach(area => {
    // Evento de mouse sobre a área para aplicar o zoom
    area.addEventListener('mouseover', () => {
        imagem.classList.add('zoom-effect'); // Adiciona o efeito de zoom
    });

    // Evento de mouse fora da área para remover o zoom
    area.addEventListener('mouseout', () => {
        imagem.classList.remove('zoom-effect'); // Remove o efeito de zoom
    });

    // Evento de clique na área
    area.addEventListener('click', (event) => {
        event.preventDefault(); // Impede o link de ser seguido imediatamente

        const link = area.getAttribute('href'); // Obtém o link da área clicada
        const zoomLevel = area.getAttribute('data-zoom'); // Obtém o nível de zoom

        // Aplica o zoom específico antes de redirecionar
        imagem.style.transform = `scale(${1 + 0.1 * zoomLevel})`; 

        // Redireciona após o efeito de zoom (300 ms de delay)
        setTimeout(() => {
            window.location.href = link; // Redireciona para o link após o zoom
        }, 300); // Tempo de animação de zoom
    });
});

    /*  Como funciona:

    HTML (index.html): Este arquivo contém a estrutura básica da página, com a imagem do mapa e áreas clicáveis definidas com a tag <area>. Cada área é associada a um link (href) e possui uma classe area-link e um atributo data-zoom, que será utilizado para definir o nível de zoom.

    CSS (styles.css): Este arquivo contém os estilos. O principal estilo de zoom é definido pela classe .zoom-effect, que usa a propriedade transform para aplicar o zoom à imagem. Há também um estilo visual para as áreas clicáveis, que pode ser removido ou modificado conforme necessário.

    JavaScript (script.js): Este arquivo lida com a lógica de interatividade. Ele adiciona eventos de mouse para aplicar o efeito de zoom (em mouseover e mouseout) e também implementa o redirecionamento para o link associado ao clicar em uma área, após aplicar o zoom.

        Como usar:

    Estrutura de arquivos:
        Salve o código HTML em um arquivo chamado index.html.
        Salve o código CSS em um arquivo chamado styles.css.
        Salve o código JavaScript em um arquivo chamado script.js.

    Imagem: Certifique-se de que a imagem mapa.jpg esteja no mesmo diretório ou ajuste o caminho da imagem no código HTML.

    Áreas clicáveis: Ajuste as coordenadas das áreas na tag <area> conforme necessário. As coordenadas são fornecidas no formato x1,y1,x2,y2, que define um retângulo. Exemplo: coords="50,50,150,150" define uma área que começa no ponto (50, 50) e vai até (150, 150) da imagem.

    Links: Substitua os valores de href com os links de destino desejados.       */ 